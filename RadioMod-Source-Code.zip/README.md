# RadioMod Source Snapshot

This archive was reconstructed from the compiled RadioMod JAR currently available in the chat.

Contents:
- `resources/` — original non-class resources from the JAR (including `META-INF/mods.toml`, assets, pack metadata, etc.)
- `decompiled-disassembly/` — readable Java bytecode/signature output generated with `javap`

Important:
This is NOT the original editable Java source project and it is not guaranteed to rebuild the JAR.
Variable names, comments, Gradle files, and exact source structure cannot be recovered losslessly from a compiled JAR alone.

For a true open-source release or a moderator request for source code, use the original Forge project/source ZIP if available.
